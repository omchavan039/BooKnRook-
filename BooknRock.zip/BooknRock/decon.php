<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: rgb(228, 206, 206);
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
 table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
  tr:nth-child(even) {
  background-color: #dddddd;
}
.co{
background-color: rgb(178, 228, 178); 

border-radius: 74px;
border: 1px solid rgb(185, 234, 196);
font-size: 18px;
position: relative;
top: 15px;
}
.yo{
  text-decoration: none;
    background-color: white;
    color:#8e8c7f ;
}
.sh{
    background-color: white;
    color:#8e8c7f;
}
.bo{
    position: relative;
    top: 280px;
}
.var{
  position: relative;
  bottom: 45px;
  left: 15px;
}
label{
  width: 100px;
  display: inline-block;
  border-radius: 15px;
}

    </style>
</head>
<body>
    <div class="topnav">
        <a href="#active" class="active">Admin Panal</a>

    </div>


    <table>
      <tr>
        <th>Book Concerts</th>
        <th>Name</th>
        <th>Date</th>
        <th>Time</th>
        <th>Location</th>
      </tr>
      <tr class="yo">
        <td>2</td>
        <td>Yo-Yo honey singh</td>
        <td>07-01-2023</td>
        <td>12 Pm</td>
        <td>Pune</td>
      </tr>
      <tr class="sh">
        <td>2</td>
        <td class="">Shreya Ghosal</td>
        <td>05-07-2023</td>
        <td>4 Pm</td>
        <td>Mumbai</td>
      </tr>
     </div>
     <h2 class="bo">Booked Concerts</h2>
     <div class="var">
     <h3>Add Concert</h3>

     <div class="container">
       <form action="index.php">
         <label for="fname" >Add Concert</label>
         <input type="text" id="fname" name="firstname" placeholder="Your name.."><br><br>
         <label for="lname">Concert Time</label>
         <input type="time" id="lname" name="lastname" placeholder="Your last name..">
     <br><br>
         <label for="lname">Concert Date</label>
         <input type="date" id="llname" name="concert Date" placeholder="Your  concert Date..">
     <br><br>
     <label for="lname">Concert Venue</label>
         <input type="text" id="llname" name="concert Date" placeholder="Your  concert venue..">
          <div class="ab"> <input type="submit" value="Submit" class="co"></div>
          </div>
           <br><br>
  </form>
</div>
     
</body>
</html>
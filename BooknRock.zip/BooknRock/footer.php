<!--
@author: RPS
-->
<div class="footer">
	<div class="wrap">
			<div class="footer-top">
				<div class="col_1_of_4 span_1_of_4">
					<div class="footer-nav">
		                <ul>
		                   <li><a href="index.php">Home</a></li>
			  		   <li><a href="concert_events.php">Concerts</a></li>
			  		   <li><a href="login.php">Login</a></li>
		                   </ul>
		              </div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<div class="textcontact">
						<p>-COPYRIGHT © 2023 Om and Omkar. ALL RIGHTS RESERVED.
							<P>-IF YOU WANTS TO CANCEL YOUR TICKETS CONTACT ON THIS NUMBER: 9518******
							WHITH YOUR TICKET ID. </P>
						</p>
					</div>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<div class=social>
					    <a href="https://gr.linkedin.com/in/vasilis-tsakiris-a2932b162"><img src="images/linkedin.png" alt="" width="42" height="42"/></a>
                        <a href="https://github.com/vasilisDev"><img src="images/github.png" alt="" width="42" height="42"/></a>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
	</div>
</body>
</html>
<!-- ================================================ -->
<style>
.content {
	padding-bottom:0px !important;
}
#form111 {
                width:500px;
                margin:50px auto;
}
#search111{
                padding:8px 15px;
                background-color:#fff;
                border:0px solid #dbdbdb;
}
#button111 {
                position:relative;
                padding:6px 15px;
                left:-8px;
                border:2px solid #207cca;
                background-color:#207cca;
                color:#fafafa;
}
#button111:hover  {
                background-color:#fafafa;
                color:#207cca;
}
</style>
